﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Net;
using System.Net.Sockets;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace server
{
    public partial class Form1 : Form
    {

        Socket serverSocket = new Socket(AddressFamily.InterNetwork, SocketType.Stream, ProtocolType.Tcp);
        List<Socket> clientSockets = new List<Socket>();        //initialing our socket list

        bool terminating = false;
        bool listening = false;
        string filePath;
        string sSelectedFile;
        string sSelectedFolder;
        string user_name = "";
        string txt_path = "";
        string txt_name = "";
        string txt_name2 = "";
        string global_path = "";
        bool username_check = false;
        string download_username = "";

        public Form1()
        {
            Control.CheckForIllegalCrossThreadCalls = false;
            this.FormClosing += new FormClosingEventHandler(Form1_FormClosing);
            InitializeComponent();
        }

        private void button_listen_Click(object sender, EventArgs e)    //starting to listen on port
        {
            int serverPort;

            if (Int32.TryParse(textBox_port.Text, out serverPort))
            {
                IPEndPoint endPoint = new IPEndPoint(IPAddress.Any, serverPort);
                serverSocket.Bind(endPoint);
                serverSocket.Listen(3);

                listening = true;
                button_listen.Enabled = false;
                //textBox_message.Enabled = true;
                //button_send.Enabled = true;

                Thread acceptThread = new Thread(Accept);
                acceptThread.Start();

                logs.AppendText("Started listening on port: " + serverPort + "\n");

            }
            else
            {
                logs.AppendText("Please check port number \n");
            }
        }

        private void Accept()
        {
            while (listening)
            {
                try
                {


                    Socket newClient = serverSocket.Accept();
                    clientSockets.Add(newClient);
                    Byte[] buffer = new Byte[1024];           //here we look for if the client is connected or not
                    newClient.Receive(buffer);

                    string incomingMessage = Encoding.Default.GetString(buffer);
                    incomingMessage = incomingMessage.Substring(0, incomingMessage.IndexOf("\0"));
                    user_name = incomingMessage;
                    logs.AppendText("Client named: " + user_name + ", tries to connect. \n");
                    //logs.AppendText(incomingMessage + "\n");

                    //logs.AppendText("\n");

                    string path = sSelectedFolder + @"\cs408_username_database.txt";
                    //logs.AppendText("path has been chosen as: " +path + "\n");
                    // Create the file, or overwrite if the file exists.
                    if (!File.Exists(path))
                    {


                        using (StreamWriter sw = File.CreateText(path))
                            sw.WriteLine(incomingMessage + "1");
                        //user_name = incomingMessage;
                        logs.AppendText("Client named: " + user_name + ", has succesfully connected.\n");
                        Thread receiveThread = new Thread(() => Receive(newClient)); // updated
                        receiveThread.Start();


                        /* File.Create(path);
                     TextWriter tw = new StreamWriter(path, true);
                     tw.WriteLine("The very first line!");
                     tw.Close();*/
                    }
                    else if (File.Exists(path))
                    {
                        string[] lines = File.ReadAllLines(path);
                        bool flag = false;
                        bool flag2 = false;
                        for (int i = 0; i < lines.Length; i++)
                        {
                            //logs.AppendText(lines[i] + "\n");
                            //string result = DoSomething(line);
                            // logs.AppendText(result);
                            if (lines[i] == incomingMessage + "1")
                            {
                                //logs.AppendText("illllllkkkk");
                                logs.AppendText("Client named: " + user_name + ", couldn't connect, username already exists \n");
                                flag2 = true;
                                flag = true;
                            }

                            else if ((lines[i] == incomingMessage + "0"))
                            {
                                //logs.AppendText("ikiiiii");
                                string text = File.ReadAllText(path);
                                text = text.Replace(incomingMessage + "0", incomingMessage + "1");
                                File.WriteAllText(path, text);
                                flag = true;
                                Thread receiveThread = new Thread(() => Receive(newClient)); // updated
                                receiveThread.Start();
                            }
                            else
                            {
                                //logs.AppendText("uuccccccc");
                                flag = false;
                            }

                        }
                        if (flag == false && flag2 == false)
                        {
                            using (StreamWriter tw = File.AppendText(path))
                            {

                                logs.AppendText("Client named: " + user_name + ", has succesfully connected.\n");
                                tw.WriteLine(incomingMessage + "1");
                                //logs.AppendText("aaaaaa");
                                Thread receiveThread = new Thread(() => Receive(newClient)); // updated
                                receiveThread.Start();
                            }

                        }





                    }

                    //logs.AppendText(incomingMessage);
                    //we check if the username exists already!!!!!!





                }
                catch
                {
                    if (terminating)
                    {
                        listening = false;
                    }
                    else
                    {
                        logs.AppendText("The socket stopped working.\n");
                    }

                }
            }
        }

        private void Receive(Socket thisClient) // updated
        {
            bool connected = true;

            while (connected && !terminating)
            {
                try
                {

                    Byte[] buffer = new Byte[2048];
                    thisClient.Receive(buffer);     //we print the incoming mesages from client.

                    string incomingMessage = Encoding.Default.GetString(buffer);
                    incomingMessage = incomingMessage.Substring(0, incomingMessage.IndexOf("\0"));

                    usernameCheck(incomingMessage);
                    if (!username_check)
                    {

                        //logs.AppendText(incomingMessage);
                        SavetoDataBase(user_name, incomingMessage);
                    }
                    if (incomingMessage.Substring(0, 1) == "=")
                    {
                        downloadFile(incomingMessage);
                    }

                    ///////buralar yeni eklendi



                    ////////////////////





                }
                catch
                {

                    if (!terminating)
                    {
                        logs.AppendText("A client has disconnected\n");
                        database_update();
                    }
                    thisClient.Close();
                    clientSockets.Remove(thisClient);
                    connected = false;
                }
            }
        }

        private void usernameCheck(string username)
        {
            if (username.Substring(0, 1) == "*")
            {
                user_name = username.Substring(1);
                username_check = true;

            }
            else if (username.Substring(0, 1) == "%")
            {
                user_name = username.Substring(1);
                print_files();
                username_check = true;
            }
            else if (username.Substring(0, 1) == "=")
            {
                username_check = true;
            }
            else if (username.Substring(0, 1) == "&")
            {
                copyfile(username);
                username_check = true;
            }
            else if (username.Substring(0, 1) == "^")
            {
                //user_name = username.Substring(1);
                delete_files(username);
                username_check = true;
            }
            else if (username.Substring(0, 1) == "#")
            {
                //user_name = username.Substring(1);
                make_public(username);
                username_check = true;
            }
            else if (username.Substring(0, 1) == ")")
            {
                //user_name = username.Substring(1);
                request_public();
                username_check = true;
            }
            else if (username.Substring(0, 1) == "(")
            {
                download_username = username.Substring(1);
                username_check = true;
            }
            else if (username.Substring(0, 1) == "<")
            {
                downloadPublicFile(username.Substring(1));
                username_check = true;
            }
            else
            {
                username_check = false;
            }
        }

        private void downloadPublicFile(string filename)
        {
            logs.AppendText(download_username);
            logs.AppendText(filename);

            string path = sSelectedFolder + @"\cs408_database.txt";
            if (File.Exists(path))
            {
                string[] lines = File.ReadAllLines(path);
                int i = 0;
                bool flag = true;
                bool flag2 = true;
                while (i < lines.Length)
                {
                    if (lines[i + 1] == download_username + filename)
                    {
                        flag = false;
                        if (lines[i + 4] == "public")
                        {
                            flag2 = false;
                            Byte[] buffer = new Byte[1024];
                            buffer = Encoding.Default.GetBytes("?" + filename);
                            foreach (Socket client in clientSockets)            //communication from server to clients
                            {
                                client.Send(buffer);
                                System.Threading.Thread.Sleep(10);


                                string path2 = sSelectedFolder + @"\" + download_username + filename;
                                string[] lines2 = File.ReadAllLines(path2);
                                int j = 0;
                                while (j < lines2.Length)
                                {
                                    //logs.AppendText(lines[i]);
                                    logs.AppendText(lines2[j] + "\n");
                                    Byte[] buffer3 = new Byte[2048];
                                    buffer3 = Encoding.Default.GetBytes("!" + lines2[j]);

                                    client.Send(buffer3);
                                    System.Threading.Thread.Sleep(10);

                                    j++;
                                }
                            }
                        }
                        else
                        {
                            logs.AppendText("File " + filename + " from user " + download_username + " is a private file! You can not download it.");
                        }



                    }
                    else
                    {
                        flag = true;
                    }
                    i = i + 5;
                }

                if (flag && flag2)
                {
                    logs.AppendText("There is no file named " + filename + " from user " + download_username + "!");
                }
            } 

        }


        private void SavetoDataBase(string username, string x)
        {

            if (x.Substring(0, 1) == "!")
            {
                txt_name = x.Substring(1, x.Length - 1);
                txt_name2 = txt_name;
            }

            string path = sSelectedFolder + @"\cs408_database.txt";


            string path2 = sSelectedFolder + @"\" + user_name + txt_name;
            global_path = path2;

            int log = 0;
            bool flag = false;
            bool first_time = false;
            if (x.Substring(0, 1) == "!")
            {
                txt_name = x.Substring(1, x.Length - 5);
                txt_name2 = txt_name;


                if (!File.Exists(path))
                {


                    using (StreamWriter sw = File.CreateText(path))
                    {
                        sw.WriteLine(user_name);
                        sw.WriteLine(user_name + txt_name);
                        //sw.WriteLine(count);
                        /*for (int i = 0; i < lines.Length; i++)
                        {
                            sw.WriteLine(lines[i]);
                        }*/

                    }
                }

                else if (File.Exists(path))
                {
                    int i = 0;
                    string[] lines2 = File.ReadAllLines(path);

                    int n = 0;
                    int one = txt_name.Length;
                    while (i < lines2.Length)
                    {
                        if (lines2[i] == user_name)
                        {
                            if (lines2[i + 1] == user_name + txt_name2)
                            {
                                n += 1;
                                if (n >= 10)
                                {
                                    txt_name2 = txt_name.Substring(0, one ) + "-" + n  ;

                                }
                                else
                                {

                                    txt_name2 = txt_name.Substring(0, one ) + "-0" + n ;

                                }


                            }



                        }


                        i = i + 5;///burası 2 ydi size ekleyince 3 yaptın date ekleyince 4 yaptın private ekledin 5 oldu
                    }


                    using (StreamWriter sw = File.AppendText(path))
                    {


                        sw.WriteLine(user_name);
                        sw.WriteLine(user_name + txt_name2);



                        //sw.WriteLine(count);
                        /* for (int j = 0; j < lines.Length; j++)
                         {
                             sw.WriteLine(lines[j]);
                         }*/


                    }
                }
                //flag = true; //sen ekledin bunu
            }
            else
            {
                //txt_path = x.Substring(1,x.Length-1);
                flag = true;
            }

            if (flag == true)
            {
                // Create the file, or overwrite if the file exists.
                if (!File.Exists(path2))
                {
                    //logs.AppendText("içerdeyim\n");
                    using (StreamWriter sw = File.CreateText(path2))
                    {

                        //logs.AppendText(x);
                        sw.WriteLine(x);

                        //sw.WriteLine("\n");
                    }
                    using (StreamWriter sw = File.AppendText(path))
                    {


                        //sw.WriteLine(user_name);
                        //sw.WriteLine(user_name + txt_name2);
                        var fileName = path2;
                        FileInfo fi = new FileInfo(fileName);
                        var size = fi.Length;
                        sw.WriteLine(size);
                        string date = DateTime.Now.ToString("yyyy-MM-dd  HH:mm:ss");
                        sw.WriteLine(date);
                        sw.WriteLine("private");
                    }
                }
                else if (File.Exists(path2))
                {
                    //logs.AppendText("dışardayım\n");

                    

                        using (StreamWriter sw = File.CreateText(sSelectedFolder + @"\" + user_name + txt_name2))
                        {
                            sw.WriteLine(x);
                        }




/*
                        using (StreamWriter sw = File.AppendText(path2))
                        {

                            //logs.AppendText(x);
                            sw.WriteLine(x);
                            //sw.WriteLine("\n");
                        }*/


                    
                    using (StreamWriter sw = File.AppendText(path))
                    {


                        //sw.WriteLine(user_name);
                        //sw.WriteLine(user_name + txt_name2);
                        var fileName = path2;
                        FileInfo fi = new FileInfo(fileName);
                        var size = fi.Length;
                        sw.WriteLine(size);
                        string date = DateTime.Now.ToString("yyyy-MM-dd  HH:mm:ss");
                        sw.WriteLine(date);
                        sw.WriteLine("private");
                    }
                }

                /*int count = 0;
                string[] lines = File.ReadAllLines(path2);
                for (int i = 0; i < lines.Length; i++)
                {
                    count += 1;
                }*/





            }


        }
        private void Form1_FormClosing(object sender, System.ComponentModel.CancelEventArgs e)
        {
            listening = false;
            terminating = true;
            Environment.Exit(0);
        }

        /* private void button_send_Click(object sender, EventArgs e)
         {
             //string message = textBox_message.Text;
             if (message != "" && message.Length <= 64)
             {
                 Byte[] buffer = Encoding.Default.GetBytes(message);
                 foreach (Socket client in clientSockets)            //communication from server to clients
                 {
                     try
                     {
                         client.Send(buffer);
                     }
                     catch
                     {
                         logs.AppendText("There is a problem! Check the connection...\n");
                         terminating = true;
                         //textBox_message.Enabled = false;
                         //button_send.Enabled = false;
                         textBox_port.Enabled = true;
                         button_listen.Enabled = true;
                         serverSocket.Close();
                     }

                 }
             }
         }*/

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void browse_button_Click(object sender, EventArgs e)
        {
            FolderBrowserDialog fbd = new FolderBrowserDialog();
            //fbd.Description = "Custom Description"; //not mandatory

            if (fbd.ShowDialog() == DialogResult.OK)
            {
                sSelectedFolder = fbd.SelectedPath;
                logs.AppendText("path chosen as: " + sSelectedFolder + "\n");
                browse_button.Enabled = false;
            }

        }

        private void database_update()
        {
            string path = sSelectedFolder + @"\cs408_username_database.txt";
            //logs.AppendText("------\n");
            //logs.AppendText(user_name);
            //logs.AppendText("------\n");
            string text = File.ReadAllText(path);
            text = text.Replace(user_name + "1", user_name + "0");
            //logs.AppendText(text);
            //logs.AppendText("aaaaa");
            File.WriteAllText(path, text);
        }

        private void print_files()
        {
            logs.AppendText("----------------------\n");
            logs.AppendText("filename                   size          upload time \n");
            //logs.AppendText(user_name);
            string path = sSelectedFolder + @"\cs408_database.txt";
            if (File.Exists(path))
            {
                int i = 0;
                string[] lines2 = File.ReadAllLines(path);
                int one = txt_name.Length;
                bool flag = true;
                while (i < lines2.Length)
                {
                    if (lines2[i] == user_name)
                    {
                        string temp = lines2[i + 1];
                        int x = user_name.Length;
                        string temp2 = temp.Substring(x);
                        logs.AppendText(temp2 + "                " + lines2[i + 2] + "                " + lines2[i + 3] + "\n");
                        flag = false;
                    }
                    i++;

                }
                if (flag)
                {
                    logs.AppendText("You didnt submit any files");
                }
            }
            else
            {
                logs.AppendText("No file has submitted");
            }
        }

        private void downloadFile(string x)
        {
            string filename = x.Substring(1);
            string path = sSelectedFolder + @"\cs408_database.txt";
            if (File.Exists(path))
            {
                string[] lines = File.ReadAllLines(path);
                int i = 0;
                bool flag =true;
                bool flag2 =true;
                while (i < lines.Length)
                {
                    if (lines[i + 1] == user_name + filename)
                    {
                        flag = false;
                       
                            flag2 = false;
                            Byte[] buffer = new Byte[1024];
                            buffer = Encoding.Default.GetBytes("?" + filename);
                            foreach (Socket client in clientSockets)            //communication from server to clients
                            {
                                client.Send(buffer);
                                System.Threading.Thread.Sleep(10);


                            string path2 = sSelectedFolder + @"\" + user_name + filename;
                            string[] lines2 = File.ReadAllLines(path2);
                                int j = 0;
                                while (j < lines2.Length)
                                {
                                    //logs.AppendText(lines[i]);
                                    //logs.AppendText(lines2[j] + "\n");
                                    Byte[] buffer3 = new Byte[2048];
                                    buffer3 = Encoding.Default.GetBytes("!" + lines2[j]);

                                    client.Send(buffer3);
                                    System.Threading.Thread.Sleep(10);

                                    j++;
                                }
                            }
                        
                       
                            
                        }
                    else
                    {
                        flag = true;
                    }
                    i = i + 5;
                } 






                /*
                logs.AppendText("ilkkk geldiği yer   " + x + "     ");
                string filename = x.Substring(1) ;
                string path = sSelectedFolder + @"\cs408_database.txt";
                if (File.Exists(path))
                {
                    int i = 0;
                    string[] lines2 = File.ReadAllLines(path);
                    int one = txt_name.Length;
                    bool flag = true;
                    bool flag2 = false;
                    string y = "";
                    while (i < lines2.Length)
                    {
                        if (lines2[i] == user_name)
                        {
                            logs.AppendText("111111");
                            if (lines2[i + 1] == user_name + filename)
                            {
                                y = sSelectedFolder + @"\" + user_name + filename;
                                logs.AppendText("----" + y + "--------");
                                //serverSocket.Send(y);

                                flag = false;
                                flag2 = true;
                            }



                        }
                        i++;

                    }
                    if (flag2)
                    {

                        Byte[] buffer = new Byte[1024];
                        buffer = Encoding.Default.GetBytes("?" + filename);
                        foreach (Socket client in clientSockets)            //communication from server to clients
                        {
                            client.Send(buffer);
                            System.Threading.Thread.Sleep(10);


                            string[] lines = File.ReadAllLines(global_path);
                            int j = 0;
                            while (j < lines.Length)
                            {
                                //logs.AppendText(lines[i]);
                                logs.AppendText(lines[j] + "\n");
                                Byte[] buffer3 = new Byte[2048];
                                buffer3 = Encoding.Default.GetBytes("!" + lines[j]);

                                client.Send(buffer3);
                                System.Threading.Thread.Sleep(10);

                                j++;
                            }
                        }

                    }
                    if (flag)
                    {
                        logs.AppendText("You dont have such file!");
                    }




                }


                */

                if (flag && flag2)
                {
                    logs.AppendText("You don't have such file!");
                }
            }
        }

        private void copyfile(string x)
        {
            
            //logs.AppendText("xxxxx" + x);
            string filename = x.Substring(1);
            string path = sSelectedFolder + @"\" + user_name + filename;
            //string path3 = sSelectedFolder + @"\dogancandeneme.txt";
            string path2 = sSelectedFolder + @"\" + user_name + filename;
            int temp = 0;
            //logs.AppendText("    " + path);

            if (File.Exists(path))
            {
                //logs.AppendText("zzzzzz");
                string path0 = sSelectedFolder + @"\cs408_database.txt";
                if (File.Exists(path0))
                {
                    //logs.AppendText("   000000  ");
                    
                    string[] lines2 = File.ReadAllLines(path0);
                    //logs.AppendText("   99999    ");
                    //int one = txt_name.Length;
                    bool flag = true;
                    bool flag2 = false;
                    string y = "";
                    string final = "";
                    int index = 0;
                    int lenght = 0;
                    lenght = (user_name+filename).Length;
                    Console.WriteLine(lenght);
                    //logs.AppendText("8888888");
                    Console.WriteLine(lines2.Length);
                    int a = 1;
                    while (a < lines2.Length)
                    {
                        Console.WriteLine("aaaaaa");
                        if (lines2[a].Length >= lenght)
                        {
                           
                            Console.WriteLine("abababab");

                            if (lines2[a].Substring(0, lenght) == user_name + filename)
                            {
                                Console.WriteLine("zzzz11");
                                //logs.AppendText("1111");
                                index = a;
                                final = lines2[index];

                            }
                        }
                        a=a+5;
                    }
                    if (final.Length != lenght)
                    {
                        //logs.AppendText("    22222   ");
                        temp = Int16.Parse(final.Substring(final.Length - 2, 2));
                        Console.WriteLine(temp);
                        temp++;
                        Console.WriteLine(temp);
                        string temp2 = "0" + temp.ToString();
                        string[] lines = File.ReadAllLines(path);
                        using (StreamWriter sw = File.CreateText(path2.Substring(0, path2.Length) + "-" + temp2))
                        {
                            int i = 0;
                            while (i < lines.Length)
                            {

                                sw.WriteLine(lines[i]);
                                i++;
                            }
                        }
                        string[] lines3 = File.ReadAllLines(path0);
                        Console.WriteLine("jjjjjj");
                        string temp3 = "";
                        int r = 0;
                        while (r < lines3.Length)
                        {
                            if (lines3[r] == user_name + filename)
                            {
                                Console.WriteLine("kkkkkkk");
                                temp3=(lines3[r + 3]);
                            }
                            r++;

                        }
                        using (StreamWriter sw = File.AppendText(path0))
                        {

                            //logs.AppendText("   bura    ");
                            sw.WriteLine(user_name);
                            sw.WriteLine(user_name + filename.Substring(0, filename.Length) + "-" + temp2);
                            var file = path;
                            FileInfo fi = new FileInfo(file);
                            var size = fi.Length;
                            sw.WriteLine(size);
                            string date = DateTime.Now.ToString("yyyy-MM-dd  HH:mm:ss");
                            sw.WriteLine(date);
                            sw.WriteLine(temp3);

                            

                        }
                    }
                    else
                    {
                     //   logs.AppendText("     333333      ");
                        string[] lines = File.ReadAllLines(path);
                        using (StreamWriter sw = File.CreateText(path2.Substring(0, path2.Length) + "-01"))
                        {
                            int i = 0;
                            while (i < lines.Length)
                            {

                                sw.WriteLine(lines[i]);
                                i++;
                            }
                        }
                        string[] lines3 = File.ReadAllLines(path0);
                        Console.WriteLine("00000000");
                        string temp3 = "";
                        int r = 0;
                        while (r < lines3.Length)
                        {
                            Console.WriteLine("5555");
                            if (lines3[r] == user_name + filename)
                            {
                                Console.WriteLine("7777");
                                Console.WriteLine("xxxx");
                                temp3=(lines3[r + 3]);
                            }
                            r++;

                        }
                        using (StreamWriter sw = File.AppendText(path0))
                        {

                            sw.WriteLine(user_name);
                            sw.WriteLine(user_name + filename.Substring(0, filename.Length) + "-01");
                            var file = path;
                            FileInfo fi = new FileInfo(file);
                            var size = fi.Length;
                            sw.WriteLine(size);
                            string date = DateTime.Now.ToString("yyyy-MM-dd  HH:mm:ss");
                            sw.WriteLine(date);
                            sw.WriteLine(temp3);

                            
                        }
                    }
                    }

                logs.AppendText("File named " + filename + " is copied!");
                }
                else
                {
                    logs.AppendText("You dont have such filename!");
                }

            }

        private void delete_files(string x)
        {
            string filename = x.Substring(1);
            string path = sSelectedFolder + @"\" + user_name + filename;
            if (File.Exists(path))
            {
                File.Delete(path);
                string path1 = sSelectedFolder + @"\cs408_database.txt";
                string[] lines = File.ReadAllLines(path1);

                Console.WriteLine("aaaaaaaa");
                string tempFile = Path.GetTempFileName();
                Console.WriteLine(tempFile);
                Console.WriteLine("bbbbbbbb");
                using (var sr = new StreamReader(path1))
                using (var sw = new StreamWriter(tempFile))
                {
                    Console.WriteLine("cccccc");
                    int i = 0;
                    while (i < lines.Length)
                    {
                        Console.WriteLine("1111");
                        if (lines[i+1] != user_name + filename)
                        {
                            Console.WriteLine("222222");
                            sw.WriteLine(lines[i]);
                            sw.WriteLine(lines[i+1]);
                            sw.WriteLine(lines[i + 2]);
                            sw.WriteLine(lines[i + 3]);
                            sw.WriteLine(lines[i + 4]);
                        }
                        i=i+5;
                    }
                }
                Console.WriteLine("333333");

                File.Delete(path1);
                File.Move(tempFile, path1);
                logs.AppendText("File " + filename + " is deleted from database.");



               /* int i = 0;
                while (i<lines.Length)
                {
                    if (lines[i] == user_name + filename)
                    {
                        logs.AppendText("aaaaafffffff");
                        lines[i - 1].Replace(lines[i-1].ToString(), "");
                        lines[i].Replace(lines[i], "");
                        lines[i+1].Replace(lines[i+1], "");
                        lines[i+2].Replace(lines[i+2], "");

                    }
                    i++;
                }*/

            }
            else
            {
                logs.AppendText("You don't have such file");
            }






        }

        private void make_public(string x)
        {
            string path = sSelectedFolder + @"\cs408_database.txt";
            string[] lines = File.ReadAllLines(path);
            int i = 0;
            bool flag = false;
            while (i<lines.Length)
            {
                if (lines[i] == user_name + x.Substring(1))
                {
                    lines[i + 3]="public";
                    flag = true;
                }
                i++;
            }
            using (StreamWriter sw = File.CreateText(path)) 
            {
                int j = 0;
                while (j < lines.Length)
                {

                    sw.WriteLine(lines[j]);
                    j++;
                }
            }

            if (flag)
            {
                logs.AppendText("File is public!");

            }
            else
            {
                logs.AppendText("There is no file!");
            }

            /* if(text.Contains(user_name+x.Substring(1)))
             text = text.Replace(user_name+x.Substring(1)+"private", user_name + x.Substring(1) + "public");
             File.WriteAllText(path, text);*/

        }
        private void request_public()
        {
            logs.AppendText("----------------------\n");
            logs.AppendText("owner          filename                   size          upload time \n");
            //logs.AppendText(user_name);
            string path = sSelectedFolder + @"\cs408_database.txt";
            if (File.Exists(path))
            {
                int i = 0;
                string[] lines2 = File.ReadAllLines(path);
                int one = txt_name.Length;
                bool flag = true;
                while (i < lines2.Length)
                {
                    if (lines2[i + 4] == "public")
                    {


                        string temp = lines2[i + 1];
                        int y = lines2[i].Length;
                        string temp2 = temp.Substring(y);
                        logs.AppendText(lines2[i] + "           " + temp2 + "                " + lines2[i + 2] + "                " + lines2[i + 3] + "\n");
                        flag = false;
                    }
                    i=i+5;

                }
                if (flag)
                {
                    logs.AppendText("No public file found!");
                }
            }
            else
            {
                logs.AppendText("No file has submitted");
            }
        }

        private void textBox_port_TextChanged(object sender, EventArgs e)
        {

        }
    }
    }
