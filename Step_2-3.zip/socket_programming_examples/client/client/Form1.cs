﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Net.Sockets;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace client
{
    public partial class Form1 : Form
    {

        bool terminating = false;
        bool connected = false;
        string sSelectedFolder;
        string filename = " ";
        Socket clientSocket;

        public Form1()
        {
            Control.CheckForIllegalCrossThreadCalls = false;
            this.FormClosing += new FormClosingEventHandler(Form1_FormClosing);
            InitializeComponent();
        }

        private void button_connect_Click(object sender, EventArgs e)
        {
            clientSocket = new Socket(AddressFamily.InterNetwork, SocketType.Stream, ProtocolType.Tcp);
            string IP = textBox_ip.Text;

            int portNum;
            if (Int32.TryParse(textBox_port.Text, out portNum))
            {
                try
                {

                    byte[] bytes = Encoding.ASCII.GetBytes(username_textbox.Text);
                    clientSocket.Connect(IP, portNum);
                    clientSocket.Send(bytes);
                    button_connect.Enabled = false;
                    disconnect_button.Enabled = true;
                    // textBox_message.Enabled = true;
                    // button_send.Enabled = true;
                    button_browse.Enabled = true;
                    connected = true;
                    //logs.AppendText("Connected to the server!\n");
                    logs.AppendText("your username: " + username_textbox.Text + ", sent to the server.\n");

                    Thread receiveThread = new Thread(Receive);
                    receiveThread.Start();

                }
                catch
                {
                    logs.AppendText("Could not connect to the server!\n");
                }
            }
            else
            {
                logs.AppendText("Check the port\n");
            }

        }

        private void Receive()
        {
            while (connected)
            {
                try
                {
                    Byte[] buffer = new Byte[2048];
                    clientSocket.Receive(buffer);

                    string incomingMessage = Encoding.Default.GetString(buffer);
                    incomingMessage = incomingMessage.Substring(0, incomingMessage.IndexOf("\0"));
                   
                    //logs.AppendText("Server: " + incomingMessage + "\n");
                    if (incomingMessage.Substring(0, 1) == "?")
                    {
                        downloadFile(incomingMessage);
                    }
                    if (incomingMessage.Substring(0, 1) == "!")
                    {
                        downloadFile(incomingMessage);
                    }

                }
                catch
                {
                    if (!terminating)
                    {
                        logs.AppendText("The server has disconnected\n");
                        button_connect.Enabled = true;
                        // textBox_message.Enabled = false;
                        //button_send.Enabled = false;
                    }

                    clientSocket.Close();
                    connected = false;
                }

            }
        }

        private void Form1_FormClosing(object sender, System.ComponentModel.CancelEventArgs e)
        {
            connected = false;
            terminating = true;
            Environment.Exit(0);
        }

        private void button_send_Click(object sender, EventArgs e)
        {




        }

        private void openFileDialog1_FileOk(object sender, CancelEventArgs e)
        {
            DialogResult result = openFileDialog1.ShowDialog();

            // <-- For debugging use.
        }



        /* int size = -1;
         DialogResult result = openFileDialog1.ShowDialog(); // Show the dialog.
             if (result == DialogResult.OK) // Test result.
             {
                 string fileName = openFileDialog1.FileName;

         // Send file fileName to remote device
         logs.AppendText("Client: " + username_textbox.Text + "sends file. /n");
                 clientSocket.SendFile(fileName);

             }*/


        private void button_browse_Click(object sender, EventArgs e)
        {
            var fileContent = string.Empty;
            var filePath = string.Empty;

            using (OpenFileDialog openFileDialog = new OpenFileDialog())
            {
                openFileDialog.InitialDirectory = "c:\\";
                //openFileDialog.Filter = "txt files (.txt)|.txt|All files (.)|.";
                openFileDialog.FilterIndex = 2;
                openFileDialog.RestoreDirectory = true;

                if (openFileDialog.ShowDialog() == DialogResult.OK)
                {


                    // PictureNameTextEdit.Text = System.IO.Path.GetFileName(FileName)
                    //Get the path of specified file
                    filePath = openFileDialog.SafeFileName;
                    logs.AppendText(filePath + "\n");
                    string filename = filePath; //to print on logs
                    filePath = "!" + filePath;
                    logs.AppendText("------------------    " + filePath + "---------------------      ");
                    string userName = "*" + username_textbox.Text;
                    //logs.AppendText(userName);
                    Byte[] buffer0 = new Byte[1024];
                    buffer0 = Encoding.Default.GetBytes(userName);
                    clientSocket.Send(buffer0);
                    fileContent = openFileDialog.FileName;
                    //logs.AppendText(fileContent);
                    string real_path = fileContent;
                    logs.AppendText(real_path + "\n");//bu total path i veriyor!!!!!!!!
                    logs.AppendText("You chosed file named: " + filename + "\n");
                    Byte[] buffer = new Byte[1024];
                    buffer = Encoding.Default.GetBytes(filePath);
                    //clientSocket.Send(buffer);
                    Byte[] buffer2 = new Byte[1024];
                    buffer2 = Encoding.Default.GetBytes(fileContent);
                    clientSocket.Send(buffer);
                    System.Threading.Thread.Sleep(20);

                    clientSocket.SendFile(real_path);
                    //clientSocket.Send(buffer2);
                    logs.AppendText("You have succesfully uploaded the file. \n");
                    /////////////
                    /* string[] lines = File.ReadAllLines(real_path);
                     int i = 0;
                     while (i < lines.Length)
                     {
                         logs.AppendText(lines[i]);
                         //logs.AppendText(lines[i] + "\n");
                         Byte[] buffer3 = new Byte[2048];
                         buffer3 = Encoding.Default.GetBytes(lines[i]);

                         clientSocket.Send(buffer3);
                         //System.Threading.Thread.Sleep(20);

                         i++;
                     }*/




                    ////////////



                    //Read the contents of the file into a stream
                    var fileStream = openFileDialog.OpenFile();

                    using (StreamReader reader = new StreamReader(fileStream))
                    {
                        fileContent = reader.ReadToEnd();
                    }
                }

            }
        }

        private void disconnect_button_Click(object sender, EventArgs e)
        {
            string userName = "*" + username_textbox.Text;
            logs.AppendText(userName);
            Byte[] buffer0 = new Byte[1024];
            buffer0 = Encoding.Default.GetBytes(userName);
            clientSocket.Send(buffer0);
            connected = false;
            terminating = true;
            clientSocket.Close();
            disconnect_button.Enabled = false;
            button_connect.Enabled = true;
        }

        private void button_request_Click(object sender, EventArgs e)
        {
            string userName = "*" + username_textbox.Text;
            //logs.AppendText(userName);
            Byte[] buffer0 = new Byte[1024];
            buffer0 = Encoding.Default.GetBytes(userName);
            clientSocket.Send(buffer0);
            string username = "%" + username_textbox.Text;
            Byte[] buffer = new Byte[1024];
            buffer = Encoding.Default.GetBytes(username);
            clientSocket.Send(buffer);
            
        }

        private void button_real_browse_Click(object sender, EventArgs e)
        {
            FolderBrowserDialog fbd = new FolderBrowserDialog();
            //fbd.Description = "Custom Description"; //not mandatory

            if (fbd.ShowDialog() == DialogResult.OK)
            {
                sSelectedFolder = fbd.SelectedPath;
                logs.AppendText("path for downloaded files chosen as: " + sSelectedFolder + "\n");
                //browse_button.Enabled = false;
            }
        }

        private void button_download_Click(object sender, EventArgs e)
        {
            string userName = "*" + username_textbox.Text;
            //logs.AppendText(userName);
            Byte[] buffer0 = new Byte[1024];
            buffer0 = Encoding.Default.GetBytes(userName);
            clientSocket.Send(buffer0);
            string filename = "=" + text_filename.Text;
            Byte[] buffer = new Byte[1024];
            buffer = Encoding.Default.GetBytes(filename);
            clientSocket.Send(buffer);
        }

        private void downloadFile(string x)
        {
            //logs.AppendText("fonksiyona girdi");
            
            string path = "";
            bool flag = false;
            if (x.Substring(0, 1) == "?")
            {
                filename = x.Substring(1);
                //flag = true;
                //logs.AppendText("g,rd,,iiiiiiii");
            }
            else
            {
                path = sSelectedFolder + @"\" + filename + ".txt";
               
                if (!File.Exists(path))
                {
                    using (StreamWriter sw = File.CreateText(path))
                    {
                        sw.WriteLine(x.Substring(1));
                    }
                }
                else
                {
                    using (StreamWriter sw = File.AppendText(path))
                    {
                        sw.WriteLine(x.Substring(1));
                    }
                }
            }
        }

        private void button_copy_Click(object sender, EventArgs e)
        {
            string userName = "*" + username_textbox.Text;
            //logs.AppendText(userName);
            Byte[] buffer0 = new Byte[1024];
            buffer0 = Encoding.Default.GetBytes(userName);
            clientSocket.Send(buffer0);
            string filename = "&" + text_copy.Text;
            Byte[] buffer = new Byte[1024];
            buffer = Encoding.Default.GetBytes(filename);
            clientSocket.Send(buffer);
        }

        private void button_delete_Click(object sender, EventArgs e)
        {
            string userName = "*" + username_textbox.Text;
            //logs.AppendText(userName);
            Byte[] buffer0 = new Byte[1024];
            buffer0 = Encoding.Default.GetBytes(userName);
            clientSocket.Send(buffer0);
            string filename = "^" + text_delete.Text;
            Byte[] buffer = new Byte[1024];
            buffer = Encoding.Default.GetBytes(filename);
            clientSocket.Send(buffer);
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void button_make_public_Click(object sender, EventArgs e)
        {
            string userName = "*" + username_textbox.Text;
            //logs.AppendText(userName);
            Byte[] buffer0 = new Byte[1024];
            buffer0 = Encoding.Default.GetBytes(userName);
            clientSocket.Send(buffer0);
            string filename = "#" +text_make_public.Text;
            Byte[] buffer = new Byte[1024];
            buffer = Encoding.Default.GetBytes(filename);
            clientSocket.Send(buffer);
        }

        private void button_request_public_Click(object sender, EventArgs e)
        {
            string userName = "*" + username_textbox.Text;
            //logs.AppendText(userName);
            Byte[] buffer0 = new Byte[1024];
            buffer0 = Encoding.Default.GetBytes(userName);
            clientSocket.Send(buffer0);
            string username = ")" + username_textbox.Text;
            Byte[] buffer = new Byte[1024];
            buffer = Encoding.Default.GetBytes(username);
            clientSocket.Send(buffer);
        }

        private void label3_Click(object sender, EventArgs e)
        {

        }

        private void richTextBox2_TextChanged(object sender, EventArgs e)
        {

        }

        private void button_download_public_Click(object sender, EventArgs e)
        {
            
        }

        private void button_download_public_Click_1(object sender, EventArgs e)
        {
            string userName = "*" + username_textbox.Text;
            Byte[] buffer0 = new Byte[1024];
            buffer0 = Encoding.Default.GetBytes(userName);
            clientSocket.Send(buffer0);
            string download_username = "(" + text_download_username.Text;
            Byte[] buffer1 = new Byte[1024];
            buffer1 = Encoding.Default.GetBytes(download_username);
            clientSocket.Send(buffer1);
            string filename = "<" + text_download_filename.Text;
            Byte[] buffer = new Byte[1024];
            buffer = Encoding.Default.GetBytes(filename);
            clientSocket.Send(buffer);
        }
    }
}